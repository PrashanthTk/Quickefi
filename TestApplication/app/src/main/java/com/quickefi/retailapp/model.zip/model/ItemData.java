package com.quickefi.retailapp.model;

public class ItemData {
    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    String label;
}
